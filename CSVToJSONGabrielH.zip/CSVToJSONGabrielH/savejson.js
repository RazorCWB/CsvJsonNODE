const fs = require('fs')
const performance = require('perf_hooks').performance;

class saveJson {
    saveConvertedJSon(file) {
        var inicioSalvar = performance.now();
        fs.writeFile('brasil.json', JSON.stringify(file, null, 4), (err) => {
            if (err) {
                throw err;
            }
            var fimSalvar = performance.now();
            console.log("Término de salvar: ", fimSalvar - inicioSalvar); 
        });
    }
}

module.exports = saveJson;
