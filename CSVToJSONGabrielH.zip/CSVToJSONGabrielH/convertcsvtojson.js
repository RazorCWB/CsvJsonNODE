const CSVToJSON = require('csvtojson')
const performance = require('perf_hooks').performance
const saveJSon = require('./savejson')


class csvtojsontrab {
    converterCSVtoJSON(file) {    
        var inicioConversão = performance.now();
        CSVToJSON().fromStream(file)
        .then(brasil => {
            new saveJSon().saveConvertedJSon(brasil);
            var fimConversao = performance.now();
            console.log("Término da conversão: ", fimConversao - inicioConversão);
        }).catch(err => {
            console.log(err);
        });
    }
}

module.exports = csvtojsontrab;



