const fs = require('fs');
const csvtojsontrab = require('./convertcsvtojson');
const performance = require('perf_hooks').performance;

var inicioLeitura = performance.now();
const file = fs.createReadStream('brasil.csv')
var fimLeitura = performance.now();
console.log("Término de leitura: ", fimLeitura - inicioLeitura);


new csvtojsontrab().converterCSVtoJSON(file);
